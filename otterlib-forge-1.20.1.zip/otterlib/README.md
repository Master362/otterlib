# OtterLib — modelos 3D y animaciones para jugadores (Forge 1.20.1)

Mod de **Minecraft Java 1.20.1 · Forge 47.x · Java 17** inspirado en los sistemas de modelos de roleplay de DEDsafío 4.
Asigna modelos de **Blockbench (`.bbmodel`)** con texturas, huesos y animaciones a jugadores, todo por comandos, sincronizado en multijugador y guardado con el mundo.

> **Estado de verificación (léelo):** el código se revisó de sintaxis con `javac`, pero **no se compiló contra Forge** ni se probó en el juego, porque el entorno donde se generó no tenía acceso a Internet. La primera compilación real la hará GitHub Actions al subir el repositorio. Si algo falla, el log de la acción lo mostrará. Ver "Limitaciones conocidas".

## 1. Cómo funciona

- **Biblioteca central en el servidor:** `config/otterlib/models/` (de tu servidor o, en un mundo local, de tu instancia).
- Al entrar un jugador, el servidor le envía todos los modelos (comprimidos y troceados) y el mapa jugador→modelo. Los cambios se difunden a todos.
- El cliente **cancela el render vanilla** del jugador asignado y dibuja el modelo propio. Si el modelo aún no llegó, se ve el jugador normal.
- Las asignaciones se guardan por UUID en `world/data/otterlib_assignments.dat`.
- **Los clientes no necesitan copiar archivos**: solo instalar el mod. Añadir personajes = copiar archivos al servidor + `/otterlib reload`.

## 2. Compilar (paso a paso)

### Opción A: GitHub Codespaces
1. Sube este repositorio a GitHub → **Code → Codespaces → Create codespace**.
2. El contenedor (`.devcontainer/`) instala **Java 17 (Temurin)** y ejecuta `./gradlew --version`.
3. En la terminal: `./gradlew build`
4. El JAR queda en `build/libs/otterlib-1.0.0.jar`.

### Opción B: GitHub Actions
Cada `push`/PR ejecuta `.github/workflows/build.yml` (JDK 17 + `./gradlew build`) y sube el JAR como artefacto **otterlib-jar** (pestaña *Actions*). Si creas un tag `v*` (p. ej. `v1.0.0`), el JAR se adjunta a un Release.

### Opción C: local
Requiere **JDK 17**. `./gradlew build` (Windows: `gradlew.bat build`). Cliente de pruebas: `./gradlew runClient`; servidor: `./gradlew runServer`.

**Sobre el Gradle Wrapper:** el repo incluye `gradlew`, `gradlew.bat` y `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.1.1). El archivo binario `gradle-wrapper.jar` **no está incluido** (no pude descargarlo al generar el proyecto): `gradlew` lo descarga solo la primera vez desde el repositorio oficial de Gradle (tag `v8.1.1`). Haz commit del JAR resultante si quieres fijarlo.

## 3. Instalación
Copia `otterlib-1.0.0.jar` a `mods/` **en el servidor y en todos los clientes** (Forge 1.20.1, 47.x). La primera vez que arranca el servidor crea `config/otterlib/models/` con tres ejemplos: `otter`, `otter_dark` y `biped_demo`.

## 4. Comandos (permiso nivel 2; alias `/otter`)
| Comando | Efecto |
|---|---|
| `/otterlib assign <jugadores> <modelo>` | Asigna un modelo |
| `/otterlib remove <jugadores>` | Quita el modelo (y detiene su animación) |
| `/otterlib list [models\|assignments]` | Lista modelos y/o asignaciones |
| `/otterlib reload` | Relee `config/otterlib/models/` y reenvía todo a los clientes |
| `/otterlib animation play <jugadores> <animacion> [default\|loop\|once\|hold]` | Reproduce una animación |
| `/otterlib animation stop <jugadores>` | Detiene la animación manual |
| `/otterlib animation list <modelo>` | Lista animaciones de un modelo |

Ejemplo: `/otterlib assign @a[tag=nutria] otter` → `/otterlib animation play @s wave`.

## 5. Añadir personajes **sin recompilar**
1. En **Blockbench** crea el modelo con formato *Generic Model* (free). Mira hacia **−Z (norte)**, pies en `Y=0`, centrado en `X=0, Z=0`; 1 bloque = 16 px (el jugador mide 24–32 px).
2. Agrupa los cubos en **grupos (huesos)**. El grupo llamado `head` sigue la mirada del jugador.
3. Crea animaciones (pestaña *Animate*). Se usan automáticamente, si existen, estos nombres: `idle`, `walk`, `run`, `sneak`, `sneak_walk`, `swim`. Cualquier otra (`wave`, `dance`…) se lanza con el comando. Usa nombres **sin espacios**.
4. **File → Save Project** → `.bbmodel`.
5. Cópialo al servidor:
   - `config/otterlib/models/<id>/model.bbmodel` (+ opcional `texture.png`, que **tiene prioridad** sobre la textura incrustada), o
   - `config/otterlib/models/<id>.bbmodel` (textura incrustada).
   El `<id>` (minúsculas, números, `_ . -`) es el nombre que se usa en los comandos.
6. `/otterlib reload` y `/otterlib assign <jugador> <id>`.

Los ejemplos se regeneran con `python3 tools/generate_examples.py` (solo librería estándar).

## 6. Integración con Morpher (investigación)
- **Sparkle's Morpher** publica, según su ficha de CurseForge, variantes **Fabric y NeoForge para Minecraft 1.21.1 y 26.1.2**; no encontré una versión Forge 1.20.1 ni documentación de una API pública para otros mods. Por eso **no hay integración directa** y no se incluye código que finja una.
- Lo que sí es posible: si tus modelos de Morpher están en formato Blockbench (`.bbmodel`), podrás reutilizar geometría, texturas y animaciones copiándolos a la biblioteca. Esto **no lo he verificado** con archivos reales de Morpher.
- Otros mods para 1.20.1 (p. ej. Customizable Player Models, con una API documentada para Forge 1.20.1) usan formatos propios (`.cpmmodel`) y no son compatibles con `.bbmodel` sin conversión.

## 7. Soporte de formato `.bbmodel`
Soportado: cubos con Box UV o UV por cara, `inflate`, `mirror_uv`, rotación de cubos, grupos anidados, animaciones de hueso (`rotation`/`position`/`scale`) con interpolación `linear`, `catmullrom` y `step`, bucle `loop`/`once`/`hold`, textura PNG incrustada o externa.

## 8. Limitaciones conocidas
- Una sola textura por modelo (la primera). Sin mallas (`mesh`). Sin Molang: valores no numéricos valen 0. Keyframes `bezier` se tratan como lineales. Sin rotación de UV por cara.
- Se omiten: armadura, objetos en mano, capa/élitros, sombra, y poses de nado/vuelo/dormir (el modelo se ve en pie). La hitbox no cambia.
- Las animaciones lanzadas por comando no se muestran a quien entre después (las asignaciones sí persisten).
- Todos los modelos se envían al conectar; con muchos modelos pesados el login tarda más (límite 16 MB por archivo).
- Las convenciones de signo de las animaciones (rotación X/Y invertida, posición X invertida) siguen mi lectura del comportamiento de Blockbench y **no están probadas visualmente**; si un movimiento sale invertido, ajusta `OtterRenderer.renderNode`.
- Versiones de Forge 47.2.0 y Gradle 8.1.1 elegidas por compatibilidad con ForgeGradle 6; cámbialas en `gradle.properties` si lo necesitas.

## 9. Estructura
```
src/main/java/dev/otterlib/{model,server,net,client,command}
src/main/resources/{META-INF/mods.toml, pack.mcmeta, otterlib_examples/}
libs/  .devcontainer/  .github/workflows/build.yml  tools/generate_examples.py
build.gradle  gradle.properties  settings.gradle  gradlew  gradlew.bat
```
