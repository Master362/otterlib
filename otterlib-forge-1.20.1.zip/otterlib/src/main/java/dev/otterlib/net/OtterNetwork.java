package dev.otterlib.net;

import dev.otterlib.OtterLib;
import dev.otterlib.client.ClientNet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/** Canal de red y paquetes (todos servidor -> cliente). */
public final class OtterNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(OtterLib.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private OtterNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, ModelList.class, ModelList::encode, ModelList::decode, ModelList::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, ModelChunk.class, ModelChunk::encode, ModelChunk::decode, ModelChunk::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, Assignments.class, Assignments::encode, Assignments::decode, Assignments::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, PlayAnimation.class, PlayAnimation::encode, PlayAnimation::decode, PlayAnimation::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    /** Lista de ids vigentes en el servidor; el cliente descarta los que no esten. */
    public record ModelList(List<String> ids) {
        void encode(FriendlyByteBuf b) {
            b.writeVarInt(ids.size());
            for (String s : ids) b.writeUtf(s);
        }

        static ModelList decode(FriendlyByteBuf b) {
            int n = b.readVarInt();
            List<String> l = new ArrayList<>(n);
            for (int i = 0; i < n; i++) l.add(b.readUtf());
            return new ModelList(l);
        }

        void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientNet.onModelList(this)));
            ctx.get().setPacketHandled(true);
        }
    }

    /** Trozo de un modelo empaquetado (gzip) para respetar el limite de tamano de paquete. */
    public record ModelChunk(String id, int index, int total, byte[] data) {
        void encode(FriendlyByteBuf b) {
            b.writeUtf(id);
            b.writeVarInt(index);
            b.writeVarInt(total);
            b.writeByteArray(data);
        }

        static ModelChunk decode(FriendlyByteBuf b) {
            return new ModelChunk(b.readUtf(), b.readVarInt(), b.readVarInt(), b.readByteArray());
        }

        void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientNet.onModelChunk(this)));
            ctx.get().setPacketHandled(true);
        }
    }

    /** Asignaciones jugador -> modelo. full=true reemplaza todo; modelo "" elimina la asignacion. */
    public record Assignments(Map<UUID, String> map, boolean full) {
        void encode(FriendlyByteBuf b) {
            b.writeBoolean(full);
            b.writeVarInt(map.size());
            for (Map.Entry<UUID, String> e : map.entrySet()) {
                b.writeUUID(e.getKey());
                b.writeUtf(e.getValue());
            }
        }

        static Assignments decode(FriendlyByteBuf b) {
            boolean full = b.readBoolean();
            int n = b.readVarInt();
            Map<UUID, String> m = new HashMap<>();
            for (int i = 0; i < n; i++) m.put(b.readUUID(), b.readUtf());
            return new Assignments(m, full);
        }

        void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientNet.onAssignments(this)));
            ctx.get().setPacketHandled(true);
        }
    }

    /** Reproduce (anim no vacia) o detiene (anim vacia) una animacion. mode: 0 por defecto, 1 loop, 2 once, 3 hold. */
    public record PlayAnimation(UUID player, String animation, int mode) {
        void encode(FriendlyByteBuf b) {
            b.writeUUID(player);
            b.writeUtf(animation);
            b.writeVarInt(mode);
        }

        static PlayAnimation decode(FriendlyByteBuf b) {
            return new PlayAnimation(b.readUUID(), b.readUtf(), b.readVarInt());
        }

        void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientNet.onPlayAnimation(this)));
            ctx.get().setPacketHandled(true);
        }
    }
}
