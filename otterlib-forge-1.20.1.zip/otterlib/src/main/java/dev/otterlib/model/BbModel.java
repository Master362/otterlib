package dev.otterlib.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Modelo de Blockbench (.bbmodel) ya interpretado: jerarquia de huesos (grupos), cubos "horneados"
 * a quads y animaciones por keyframes. No usa clases de renderizado, por lo que es seguro en servidor.
 *
 * Soportado: cubos (box UV y UV por cara), rotacion de cubos, inflate, mirror_uv, grupos anidados,
 * animaciones de hueso (rotation / position / scale) con interpolacion linear, catmullrom y step.
 * No soportado: mallas, multiples texturas por modelo, Molang/expresiones (se evaluan como 0),
 * rotacion de UV por cara, keyframes bezier (se tratan como lineales).
 */
public final class BbModel {
    private static final float DEG = (float) (Math.PI / 180.0);
    private static final String[] FACES = {"north", "east", "south", "west", "up", "down"};
    private static final float[][] NORMALS = {{0, 0, -1}, {1, 0, 0}, {0, 0, 1}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}};

    public enum LoopMode { LOOP, ONCE, HOLD }

    public static final class Quad {
        public final float[] x = new float[4];
        public final float[] y = new float[4];
        public final float[] z = new float[4];
        public final float[] u = new float[4];
        public final float[] v = new float[4];
        public float nx, ny, nz;
    }

    public static final class Node {
        public final String name;
        public final String uuid;
        public final boolean isHead;
        public final float[] origin = new float[3];
        public final float[] rotation = new float[3];
        public final List<Quad> quads = new ArrayList<>();
        public final List<Node> children = new ArrayList<>();

        Node(String name, String uuid) {
            this.name = name;
            this.uuid = uuid;
            this.isHead = name.equalsIgnoreCase("head");
        }
    }

    private static final int INTERP_LINEAR = 0, INTERP_CATMULL = 1, INTERP_STEP = 2;

    private static final class Keyframe {
        final float time;
        final int interp;
        final float[] v;

        Keyframe(float time, int interp, float[] v) {
            this.time = time;
            this.interp = interp;
            this.v = v;
        }
    }

    private static final class BoneAnim {
        final List<Keyframe> rotation = new ArrayList<>();
        final List<Keyframe> position = new ArrayList<>();
        final List<Keyframe> scale = new ArrayList<>();
    }

    public static final class Animation {
        public final String name;
        public final LoopMode loop;
        public final float length;
        private final Map<String, BoneAnim> byKey = new HashMap<>();

        Animation(String name, LoopMode loop, float length) {
            this.name = name;
            this.loop = loop;
            this.length = length;
        }

        /** Ajusta el tiempo (segundos) segun el modo de bucle. */
        public float wrap(float t, LoopMode mode) {
            if (t < 0) t = 0;
            if (length <= 0) return 0;
            return mode == LoopMode.LOOP ? t % length : Math.min(t, length);
        }

        /** Rellena rot (grados, valores de Blockbench), pos (pixeles) y scl (factor) para el nodo en el tiempo t. */
        public void sample(Node n, float t, float[] rot, float[] pos, float[] scl) {
            Arrays.fill(rot, 0f);
            Arrays.fill(pos, 0f);
            Arrays.fill(scl, 1f);
            BoneAnim b = byKey.get(n.uuid);
            if (b == null) b = byKey.get("name:" + n.name);
            if (b == null) return;
            sampleTrack(b.rotation, t, rot);
            sampleTrack(b.position, t, pos);
            sampleTrack(b.scale, t, scl);
        }

        private static void sampleTrack(List<Keyframe> list, float t, float[] out) {
            int n = list.size();
            if (n == 0) return;
            Keyframe first = list.get(0);
            Keyframe last = list.get(n - 1);
            if (t <= first.time || n == 1) {
                System.arraycopy(first.v, 0, out, 0, 3);
                return;
            }
            if (t >= last.time) {
                System.arraycopy(last.v, 0, out, 0, 3);
                return;
            }
            int i = 0;
            while (i < n - 2 && list.get(i + 1).time <= t) i++;
            Keyframe a = list.get(i);
            Keyframe b = list.get(i + 1);
            float span = b.time - a.time;
            float f = span <= 1e-6f ? 1f : (t - a.time) / span;
            if (a.interp == INTERP_STEP) {
                System.arraycopy(a.v, 0, out, 0, 3);
            } else if (a.interp == INTERP_CATMULL || b.interp == INTERP_CATMULL) {
                Keyframe p0 = i > 0 ? list.get(i - 1) : a;
                Keyframe p3 = i + 2 < n ? list.get(i + 2) : b;
                for (int k = 0; k < 3; k++) out[k] = catmull(p0.v[k], a.v[k], b.v[k], p3.v[k], f);
            } else {
                for (int k = 0; k < 3; k++) out[k] = a.v[k] + (b.v[k] - a.v[k]) * f;
            }
        }

        private static float catmull(float p0, float p1, float p2, float p3, float t) {
            float t2 = t * t, t3 = t2 * t;
            return 0.5f * ((2f * p1) + (-p0 + p2) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 + (-p0 + 3f * p1 - 3f * p2 + p3) * t3);
        }
    }

    public final String name;
    public final int texWidth;
    public final int texHeight;
    /** Nodo raiz virtual sin transformacion. */
    public final Node root = new Node("root", "root");
    public final Map<String, Animation> animations = new LinkedHashMap<>();
    /** PNG incrustado en el .bbmodel (primera textura) o null. */
    public byte[] embeddedTexture;

    private BbModel(String name, int w, int h) {
        this.name = name;
        this.texWidth = Math.max(1, w);
        this.texHeight = Math.max(1, h);
    }

    /** Busca una animacion ignorando mayusculas. */
    public Animation findAnimation(String wanted) {
        if (wanted == null) return null;
        Animation a = animations.get(wanted);
        if (a != null) return a;
        for (Map.Entry<String, Animation> e : animations.entrySet()) {
            if (e.getKey().equalsIgnoreCase(wanted)) return e.getValue();
        }
        return null;
    }

    public List<String> animationNames() {
        return Collections.unmodifiableList(new ArrayList<>(animations.keySet()));
    }

    // ------------------------------------------------------------------ parsing

    public static BbModel parse(String json) {
        if (json != null && !json.isEmpty() && json.charAt(0) == '\uFEFF') json = json.substring(1);
        JsonObject rootObj = JsonParser.parseString(json).getAsJsonObject();

        boolean metaBox = false;
        if (rootObj.has("meta") && rootObj.get("meta").isJsonObject()) {
            JsonObject meta = rootObj.getAsJsonObject("meta");
            metaBox = meta.has("box_uv") && meta.get("box_uv").getAsBoolean();
        }
        int w = 64, h = 64;
        if (rootObj.has("resolution") && rootObj.get("resolution").isJsonObject()) {
            JsonObject res = rootObj.getAsJsonObject("resolution");
            if (res.has("width")) w = res.get("width").getAsInt();
            if (res.has("height")) h = res.get("height").getAsInt();
        }
        String name = rootObj.has("name") ? rootObj.get("name").getAsString() : "model";
        BbModel model = new BbModel(name, w, h);

        Map<String, JsonObject> elements = new LinkedHashMap<>();
        if (rootObj.has("elements")) {
            for (JsonElement e : rootObj.getAsJsonArray("elements")) {
                JsonObject o = e.getAsJsonObject();
                if (o.has("uuid")) elements.put(o.get("uuid").getAsString(), o);
            }
        }
        if (rootObj.has("outliner") && rootObj.get("outliner").isJsonArray() && rootObj.getAsJsonArray("outliner").size() > 0) {
            model.parseChildren(rootObj.getAsJsonArray("outliner"), model.root, elements, metaBox);
        } else {
            for (JsonObject o : elements.values()) model.addCube(model.root, o, metaBox);
        }

        if (rootObj.has("textures") && rootObj.get("textures").isJsonArray()) {
            JsonArray tx = rootObj.getAsJsonArray("textures");
            if (tx.size() > 0 && tx.get(0).isJsonObject()) {
                JsonObject t0 = tx.get(0).getAsJsonObject();
                if (t0.has("source") && !t0.get("source").isJsonNull()) {
                    String src = t0.get("source").getAsString();
                    if (src.startsWith("data:image/png;base64,")) {
                        model.embeddedTexture = Base64.getMimeDecoder().decode(src.substring(src.indexOf(',') + 1));
                    }
                }
            }
        }

        if (rootObj.has("animations") && rootObj.get("animations").isJsonArray()) {
            for (JsonElement ae : rootObj.getAsJsonArray("animations")) {
                Animation a = parseAnimation(ae.getAsJsonObject());
                if (a != null) model.animations.put(a.name, a);
            }
        }
        return model;
    }

    private void parseChildren(JsonArray arr, Node parent, Map<String, JsonObject> elements, boolean metaBox) {
        for (JsonElement item : arr) {
            if (item.isJsonPrimitive()) {
                JsonObject el = elements.get(item.getAsString());
                if (el != null) addCube(parent, el, metaBox);
            } else if (item.isJsonObject()) {
                JsonObject g = item.getAsJsonObject();
                if (g.has("export") && !g.get("export").getAsBoolean()) continue;
                String gname = g.has("name") ? g.get("name").getAsString() : "group";
                String guuid = g.has("uuid") ? g.get("uuid").getAsString() : gname;
                Node node = new Node(gname, guuid);
                float[] o = arr3(g, "origin");
                float[] r = arr3(g, "rotation");
                System.arraycopy(o, 0, node.origin, 0, 3);
                System.arraycopy(r, 0, node.rotation, 0, 3);
                parent.children.add(node);
                if (g.has("children") && g.get("children").isJsonArray()) {
                    parseChildren(g.getAsJsonArray("children"), node, elements, metaBox);
                }
            }
        }
    }

    private void addCube(Node parent, JsonObject e, boolean metaBox) {
        if (e.has("export") && !e.get("export").getAsBoolean()) return;
        if (e.has("type") && !"cube".equals(e.get("type").getAsString())) return;
        if (!e.has("from") || !e.has("to")) return;

        float[] from = arr3(e, "from");
        float[] to = arr3(e, "to");
        float[] origin = arr3(e, "origin");
        float[] rot = arr3(e, "rotation");
        float inflate = e.has("inflate") ? e.get("inflate").getAsFloat() : 0f;
        boolean boxUv = e.has("box_uv") ? e.get("box_uv").getAsBoolean() : metaBox;
        boolean mirror = e.has("mirror_uv") && e.get("mirror_uv").getAsBoolean();

        float x0 = from[0] - inflate, y0 = from[1] - inflate, z0 = from[2] - inflate;
        float x1 = to[0] + inflate, y1 = to[1] + inflate, z1 = to[2] + inflate;

        float[][] rect = new float[6][];
        boolean[] present = new boolean[6];
        if (boxUv && e.has("uv_offset")) {
            JsonArray off = e.getAsJsonArray("uv_offset");
            float u0 = off.get(0).getAsFloat(), v0 = off.get(1).getAsFloat();
            float cw = to[0] - from[0], ch = to[1] - from[1], cd = to[2] - from[2];
            rect[0] = new float[]{u0 + cd, v0 + cd, u0 + cd + cw, v0 + cd + ch};
            rect[1] = new float[]{u0, v0 + cd, u0 + cd, v0 + cd + ch};
            rect[2] = new float[]{u0 + 2 * cd + cw, v0 + cd, u0 + 2 * cd + 2 * cw, v0 + cd + ch};
            rect[3] = new float[]{u0 + cd + cw, v0 + cd, u0 + 2 * cd + cw, v0 + cd + ch};
            rect[4] = new float[]{u0 + cd, v0, u0 + cd + cw, v0 + cd};
            rect[5] = new float[]{u0 + cd + cw, v0, u0 + cd + 2 * cw, v0 + cd};
            if (mirror) {
                float[] tmp = rect[1];
                rect[1] = rect[3];
                rect[3] = tmp;
                for (int i = 0; i < 6; i++) {
                    float a = rect[i][0];
                    rect[i][0] = rect[i][2];
                    rect[i][2] = a;
                }
            }
            Arrays.fill(present, true);
        } else if (e.has("faces") && e.get("faces").isJsonObject()) {
            JsonObject faces = e.getAsJsonObject("faces");
            for (int i = 0; i < 6; i++) {
                if (!faces.has(FACES[i]) || !faces.get(FACES[i]).isJsonObject()) continue;
                JsonObject f = faces.getAsJsonObject(FACES[i]);
                JsonElement tex = f.get("texture");
                if (tex != null && tex.isJsonNull()) continue;
                if (!f.has("uv") || !f.get("uv").isJsonArray() || f.getAsJsonArray("uv").size() < 4) continue;
                JsonArray uv = f.getAsJsonArray("uv");
                rect[i] = new float[]{uv.get(0).getAsFloat(), uv.get(1).getAsFloat(), uv.get(2).getAsFloat(), uv.get(3).getAsFloat()};
                present[i] = true;
            }
        } else {
            return;
        }

        boolean rotated = rot[0] != 0f || rot[1] != 0f || rot[2] != 0f;
        Quaternionf q = rotated ? new Quaternionf().rotationZYX(rot[2] * DEG, rot[1] * DEG, rot[0] * DEG) : null;

        for (int f = 0; f < 6; f++) {
            if (!present[f]) continue;
            float[][] c = faceCorners(f, x0, y0, z0, x1, y1, z1);
            float u1 = rect[f][0] / texWidth, v1 = rect[f][1] / texHeight;
            float u2 = rect[f][2] / texWidth, v2 = rect[f][3] / texHeight;
            float[] us = {u1, u2, u2, u1};
            float[] vs = {v1, v1, v2, v2};
            Quad quad = new Quad();
            float[] n = NORMALS[f];
            Vector3f nv = new Vector3f(n[0], n[1], n[2]);
            if (rotated) q.transform(nv);
            quad.nx = nv.x;
            quad.ny = nv.y;
            quad.nz = nv.z;
            for (int i = 0; i < 4; i++) {
                Vector3f p = new Vector3f(c[i][0], c[i][1], c[i][2]);
                if (rotated) {
                    p.sub(origin[0], origin[1], origin[2]);
                    q.transform(p);
                    p.add(origin[0], origin[1], origin[2]);
                }
                quad.x[i] = p.x;
                quad.y[i] = p.y;
                quad.z[i] = p.z;
                quad.u[i] = us[i];
                quad.v[i] = vs[i];
            }
            parent.quads.add(quad);
        }
    }

    /** Esquinas TL, TR, BR, BL vistas desde fuera de la cara. */
    private static float[][] faceCorners(int face, float x0, float y0, float z0, float x1, float y1, float z1) {
        switch (face) {
            case 0: // north (-Z)
                return new float[][]{{x1, y1, z0}, {x0, y1, z0}, {x0, y0, z0}, {x1, y0, z0}};
            case 1: // east (+X)
                return new float[][]{{x1, y1, z1}, {x1, y1, z0}, {x1, y0, z0}, {x1, y0, z1}};
            case 2: // south (+Z)
                return new float[][]{{x0, y1, z1}, {x1, y1, z1}, {x1, y0, z1}, {x0, y0, z1}};
            case 3: // west (-X)
                return new float[][]{{x0, y1, z0}, {x0, y1, z1}, {x0, y0, z1}, {x0, y0, z0}};
            case 4: // up (+Y)
                return new float[][]{{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}};
            default: // down (-Y)
                return new float[][]{{x0, y0, z1}, {x1, y0, z1}, {x1, y0, z0}, {x0, y0, z0}};
        }
    }

    private static Animation parseAnimation(JsonObject a) {
        String name = a.has("name") ? a.get("name").getAsString() : null;
        if (name == null || name.isEmpty()) return null;
        LoopMode mode = LoopMode.ONCE;
        if (a.has("loop") && !a.get("loop").isJsonNull()) {
            String l = a.get("loop").getAsString().toLowerCase(Locale.ROOT);
            if (l.equals("loop")) mode = LoopMode.LOOP;
            else if (l.equals("hold")) mode = LoopMode.HOLD;
        }
        float length = a.has("length") ? a.get("length").getAsFloat() : 0f;
        Animation anim = new Animation(name, mode, length);
        if (a.has("animators") && a.get("animators").isJsonObject()) {
            for (Map.Entry<String, JsonElement> en : a.getAsJsonObject("animators").entrySet()) {
                if (!en.getValue().isJsonObject()) continue;
                JsonObject an = en.getValue().getAsJsonObject();
                String type = an.has("type") ? an.get("type").getAsString() : "bone";
                if (!"bone".equals(type)) continue;
                BoneAnim ba = new BoneAnim();
                if (an.has("keyframes") && an.get("keyframes").isJsonArray()) {
                    for (JsonElement ke : an.getAsJsonArray("keyframes")) {
                        JsonObject k = ke.getAsJsonObject();
                        if (!k.has("channel") || !k.has("time")) continue;
                        String ch = k.get("channel").getAsString();
                        List<Keyframe> target = ch.equals("rotation") ? ba.rotation : ch.equals("position") ? ba.position : ch.equals("scale") ? ba.scale : null;
                        if (target == null) continue;
                        float[] v = new float[3];
                        if (k.has("data_points") && k.get("data_points").isJsonArray() && k.getAsJsonArray("data_points").size() > 0) {
                            JsonObject dp = k.getAsJsonArray("data_points").get(0).getAsJsonObject();
                            v[0] = num(dp.get("x"));
                            v[1] = num(dp.get("y"));
                            v[2] = num(dp.get("z"));
                        }
                        int interp = INTERP_LINEAR;
                        if (k.has("interpolation") && !k.get("interpolation").isJsonNull()) {
                            String i = k.get("interpolation").getAsString();
                            if (i.equals("catmullrom")) interp = INTERP_CATMULL;
                            else if (i.equals("step")) interp = INTERP_STEP;
                        }
                        target.add(new Keyframe(k.get("time").getAsFloat(), interp, v));
                    }
                }
                sortByTime(ba.rotation);
                sortByTime(ba.position);
                sortByTime(ba.scale);
                anim.byKey.put(en.getKey(), ba);
                if (an.has("name")) anim.byKey.putIfAbsent("name:" + an.get("name").getAsString(), ba);
            }
        }
        return anim;
    }

    private static void sortByTime(List<Keyframe> l) {
        l.sort((p, q) -> Float.compare(p.time, q.time));
    }

    private static float num(JsonElement e) {
        if (e == null || e.isJsonNull()) return 0f;
        try {
            if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) return e.getAsFloat();
            return Float.parseFloat(e.getAsString().trim());
        } catch (RuntimeException ex) {
            return 0f; // expresiones Molang no soportadas
        }
    }

    private static float[] arr3(JsonObject o, String key) {
        float[] r = new float[3];
        if (o.has(key) && o.get(key).isJsonArray()) {
            JsonArray a = o.getAsJsonArray(key);
            for (int i = 0; i < 3 && i < a.size(); i++) r[i] = a.get(i).getAsFloat();
        }
        return r;
    }
}
