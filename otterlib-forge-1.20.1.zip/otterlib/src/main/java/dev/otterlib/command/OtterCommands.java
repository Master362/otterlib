package dev.otterlib.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.tree.LiteralCommandNode;
import com.mojang.authlib.GameProfile;
import dev.otterlib.server.AssignmentData;
import dev.otterlib.server.ModelLibrary;
import dev.otterlib.server.ModelSync;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** /otterlib (alias /otter), requiere permiso 2. */
public final class OtterCommands {
    private static final SuggestionProvider<CommandSourceStack> MODELS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(ModelLibrary.ids(), builder);
    private static final SuggestionProvider<CommandSourceStack> ANIMATIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(ModelLibrary.allAnimationNames(), builder);
    private static final List<String> MODES = List.of("default", "loop", "once", "hold");

    private OtterCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("otterlib")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("assign")
                        .then(Commands.argument("targets", EntityArgument.players())
                                .then(Commands.argument("model", StringArgumentType.word())
                                        .suggests(MODELS)
                                        .executes(OtterCommands::assign))))
                .then(Commands.literal("remove")
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(OtterCommands::remove)))
                .then(Commands.literal("list")
                        .executes(ctx -> list(ctx, true, true))
                        .then(Commands.literal("models").executes(ctx -> list(ctx, true, false)))
                        .then(Commands.literal("assignments").executes(ctx -> list(ctx, false, true))))
                .then(Commands.literal("reload").executes(OtterCommands::reload))
                .then(Commands.literal("animation")
                        .then(Commands.literal("play")
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .then(Commands.argument("animation", StringArgumentType.word())
                                                .suggests(ANIMATIONS)
                                                .executes(ctx -> play(ctx, "default"))
                                                .then(Commands.argument("mode", StringArgumentType.word())
                                                        .suggests((ctx, b) -> SharedSuggestionProvider.suggest(MODES, b))
                                                        .executes(ctx -> play(ctx, StringArgumentType.getString(ctx, "mode")))))))
                        .then(Commands.literal("stop")
                                .then(Commands.argument("targets", EntityArgument.players())
                                        .executes(OtterCommands::stop)))
                        .then(Commands.literal("list")
                                .then(Commands.argument("model", StringArgumentType.word())
                                        .suggests(MODELS)
                                        .executes(OtterCommands::listAnimations))));

        LiteralCommandNode<CommandSourceStack> node = dispatcher.register(root);
        dispatcher.register(Commands.literal("otter").requires(src -> src.hasPermission(2)).redirect(node));
    }

    private static int assign(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack src = ctx.getSource();
        String id = StringArgumentType.getString(ctx, "model").toLowerCase(Locale.ROOT);
        if (!ModelLibrary.has(id)) {
            src.sendFailure(Component.literal("Modelo desconocido '" + id + "'. Modelos disponibles: " + String.join(", ", ModelLibrary.ids())));
            return 0;
        }
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(ctx, "targets");
        AssignmentData data = AssignmentData.get(src.getServer());
        for (ServerPlayer p : targets) {
            data.set(p.getUUID(), id);
            ModelSync.broadcastAssignment(p.getUUID(), id);
        }
        src.sendSuccess(() -> Component.literal("Modelo '" + id + "' asignado a " + targets.size() + " jugador(es)."), true);
        return targets.size();
    }

    private static int remove(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack src = ctx.getSource();
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(ctx, "targets");
        AssignmentData data = AssignmentData.get(src.getServer());
        int removed = 0;
        for (ServerPlayer p : targets) {
            if (data.remove(p.getUUID())) removed++;
            ModelSync.broadcastAssignment(p.getUUID(), null);
            ModelSync.broadcastAnimation(p.getUUID(), "", 0);
        }
        final int count = removed;
        src.sendSuccess(() -> Component.literal("Modelo quitado a " + count + " jugador(es)."), true);
        return removed;
    }

    private static int list(CommandContext<CommandSourceStack> ctx, boolean models, boolean assignments) {
        CommandSourceStack src = ctx.getSource();
        MinecraftServer server = src.getServer();
        if (models) {
            Collection<ModelLibrary.Entry> es = ModelLibrary.entries();
            src.sendSuccess(() -> Component.literal("Modelos (" + es.size() + ") en " + ModelLibrary.directory()), false);
            for (ModelLibrary.Entry e : es) {
                src.sendSuccess(() -> Component.literal(" - " + e.id() + "  [" + e.animations().size() + " animaciones"
                        + (e.hasTexture() ? "" : ", sin textura") + "]"), false);
            }
        }
        if (assignments) {
            Map<UUID, String> all = AssignmentData.get(server).all();
            src.sendSuccess(() -> Component.literal("Asignaciones (" + all.size() + "):"), false);
            for (Map.Entry<UUID, String> en : all.entrySet()) {
                String who = nameOf(server, en.getKey());
                String model = en.getValue() + (ModelLibrary.has(en.getValue()) ? "" : "  (FALTA en la biblioteca)");
                src.sendSuccess(() -> Component.literal(" - " + who + " -> " + model), false);
            }
        }
        return 1;
    }

    private static String nameOf(MinecraftServer server, UUID id) {
        ServerPlayer online = server.getPlayerList().getPlayer(id);
        if (online != null) return online.getGameProfile().getName();
        if (server.getProfileCache() != null) {
            Optional<GameProfile> gp = server.getProfileCache().get(id);
            if (gp.isPresent()) return gp.get().getName();
        }
        return id.toString();
    }

    private static int reload(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        ModelLibrary.Result r = ModelLibrary.reload();
        ModelSync.broadcastLibrary();
        src.sendSuccess(() -> Component.literal("Biblioteca recargada: " + r.loaded() + " modelo(s) enviados a los clientes."), true);
        for (String err : r.errors()) src.sendFailure(Component.literal("Error: " + err));
        return r.loaded();
    }

    private static int play(CommandContext<CommandSourceStack> ctx, String modeName) throws CommandSyntaxException {
        CommandSourceStack src = ctx.getSource();
        String wanted = StringArgumentType.getString(ctx, "animation");
        int mode = MODES.indexOf(modeName.toLowerCase(Locale.ROOT));
        if (mode < 0) {
            src.sendFailure(Component.literal("Modo invalido. Usa: " + String.join(", ", MODES)));
            return 0;
        }
        AssignmentData data = AssignmentData.get(src.getServer());
        int ok = 0;
        List<String> problems = new ArrayList<>();
        for (ServerPlayer p : EntityArgument.getPlayers(ctx, "targets")) {
            String model = data.get(p.getUUID());
            String name = model == null ? null : ModelLibrary.canonicalAnimation(model, wanted);
            if (model == null) {
                problems.add(p.getGameProfile().getName() + " no tiene modelo asignado");
            } else if (name == null) {
                problems.add("el modelo '" + model + "' de " + p.getGameProfile().getName() + " no tiene la animacion '" + wanted + "'");
            } else {
                ModelSync.broadcastAnimation(p.getUUID(), name, mode);
                ok++;
            }
        }
        final int count = ok;
        if (ok > 0) src.sendSuccess(() -> Component.literal("Animacion '" + wanted + "' reproducida en " + count + " jugador(es)."), true);
        for (String s : problems) src.sendFailure(Component.literal(s));
        return ok;
    }

    private static int stop(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(ctx, "targets");
        for (ServerPlayer p : targets) ModelSync.broadcastAnimation(p.getUUID(), "", 0);
        ctx.getSource().sendSuccess(() -> Component.literal("Animacion detenida en " + targets.size() + " jugador(es)."), true);
        return targets.size();
    }

    private static int listAnimations(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        String id = StringArgumentType.getString(ctx, "model").toLowerCase(Locale.ROOT);
        ModelLibrary.Entry e = ModelLibrary.get(id);
        if (e == null) {
            src.sendFailure(Component.literal("Modelo desconocido '" + id + "'."));
            return 0;
        }
        src.sendSuccess(() -> Component.literal("Animaciones de '" + id + "': " + (e.animations().isEmpty() ? "(ninguna)" : String.join(", ", e.animations()))), false);
        return e.animations().size();
    }
}
