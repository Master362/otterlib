package dev.otterlib.server;

import dev.otterlib.OtterLib;
import dev.otterlib.model.BbModel;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Biblioteca central de modelos del servidor. Lee config/otterlib/models/:
 *   models/&lt;id&gt;/model.bbmodel (+ texture.png opcional)   o   models/&lt;id&gt;.bbmodel
 * y mantiene un paquete comprimido de cada modelo listo para enviarlo a los clientes.
 */
public final class ModelLibrary {
    public record Entry(String id, byte[] packed, List<String> animations, boolean hasTexture) {}

    public record Result(int loaded, List<String> errors) {}

    /** Modelo + textura descomprimidos (lado cliente). */
    public record Bundle(byte[] modelJson, byte[] texture) {}

    private static final Pattern ID = Pattern.compile("[a-z0-9_.-]+");
    private static final long MAX_FILE_BYTES = 16L * 1024 * 1024;
    private static final String[] EXAMPLES = {
            "otter/model.bbmodel",
            "otter_dark/model.bbmodel",
            "otter_dark/texture.png",
            "biped_demo.bbmodel"
    };

    private static volatile Map<String, Entry> entries = Collections.emptyMap();

    private ModelLibrary() {}

    public static Path directory() {
        return FMLPaths.CONFIGDIR.get().resolve("otterlib").resolve("models");
    }

    public static Collection<Entry> entries() {
        return entries.values();
    }

    public static Collection<String> ids() {
        return entries.keySet();
    }

    public static boolean has(String id) {
        return entries.containsKey(id);
    }

    public static Entry get(String id) {
        return entries.get(id);
    }

    public static Collection<String> allAnimationNames() {
        TreeSet<String> set = new TreeSet<>();
        for (Entry e : entries.values()) set.addAll(e.animations());
        return set;
    }

    /** Nombre canonico de la animacion (ignorando mayusculas) o null si el modelo no la tiene. */
    public static String canonicalAnimation(String modelId, String wanted) {
        Entry e = entries.get(modelId);
        if (e == null) return null;
        for (String a : e.animations()) {
            if (a.equalsIgnoreCase(wanted)) return a;
        }
        return null;
    }

    public static synchronized Result reload() {
        List<String> errors = new ArrayList<>();
        Map<String, Entry> map = new TreeMap<>();
        Path dir = directory();
        try {
            boolean fresh = !Files.isDirectory(dir);
            Files.createDirectories(dir);
            if (fresh || isEmpty(dir)) installExamples(dir, errors);
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
                List<Path> paths = new ArrayList<>();
                ds.forEach(paths::add);
                Collections.sort(paths);
                for (Path p : paths) {
                    String fn = p.getFileName().toString();
                    try {
                        Entry e = null;
                        if (Files.isDirectory(p)) {
                            e = loadFolder(p, fn);
                        } else if (fn.toLowerCase(Locale.ROOT).endsWith(".bbmodel")) {
                            e = loadFile(p, fn.substring(0, fn.length() - ".bbmodel".length()));
                        }
                        if (e != null) {
                            if (map.containsKey(e.id())) errors.add(fn + ": id duplicado '" + e.id() + "'");
                            else map.put(e.id(), e);
                        }
                    } catch (Exception ex) {
                        errors.add(fn + ": " + ex.getMessage());
                    }
                }
            }
        } catch (IOException ex) {
            errors.add("No se pudo leer " + dir + ": " + ex.getMessage());
        }
        entries = Collections.unmodifiableMap(map);
        for (String err : errors) OtterLib.LOGGER.warn("[OtterLib] {}", err);
        OtterLib.LOGGER.info("[OtterLib] {} modelo(s) cargado(s) desde {}", map.size(), dir);
        return new Result(map.size(), errors);
    }

    private static boolean isEmpty(Path dir) throws IOException {
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            return !ds.iterator().hasNext();
        }
    }

    private static void installExamples(Path dir, List<String> errors) {
        for (String rel : EXAMPLES) {
            try (InputStream in = ModelLibrary.class.getResourceAsStream("/otterlib_examples/" + rel)) {
                if (in == null) {
                    errors.add("Ejemplo no encontrado en el JAR: " + rel);
                    continue;
                }
                Path target = dir.resolve(rel);
                Files.createDirectories(target.getParent());
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                errors.add("No se pudo instalar ejemplo " + rel + ": " + ex.getMessage());
            }
        }
    }

    private static Entry loadFolder(Path folder, String name) throws IOException {
        Path model = folder.resolve("model.bbmodel");
        Path texture = folder.resolve("texture.png");
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(folder)) {
            ds.forEach(files::add);
        }
        Collections.sort(files);
        if (!Files.isRegularFile(model)) {
            model = null;
            for (Path f : files) {
                if (f.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".bbmodel")) {
                    model = f;
                    break;
                }
            }
        }
        if (model == null) return null; // carpeta sin modelo: se ignora
        if (!Files.isRegularFile(texture)) {
            texture = null;
            for (Path f : files) {
                if (f.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png")) {
                    texture = f;
                    break;
                }
            }
        }
        return build(name, model, texture);
    }

    private static Entry loadFile(Path file, String name) throws IOException {
        return build(name, file, null);
    }

    private static Entry build(String rawId, Path modelFile, Path textureFile) throws IOException {
        String id = rawId.toLowerCase(Locale.ROOT);
        if (!ID.matcher(id).matches()) {
            throw new IllegalArgumentException("id invalido '" + rawId + "' (usa minusculas, numeros, _ . -)");
        }
        if (Files.size(modelFile) > MAX_FILE_BYTES) throw new IOException("modelo mayor de 16 MB");
        String json = Files.readString(modelFile, StandardCharsets.UTF_8);
        BbModel model = BbModel.parse(json);
        byte[] tex = null;
        if (textureFile != null) {
            if (Files.size(textureFile) > MAX_FILE_BYTES) throw new IOException("textura mayor de 16 MB");
            tex = Files.readAllBytes(textureFile);
        } else if (model.embeddedTexture != null) {
            tex = model.embeddedTexture;
        }
        byte[] packed = pack(json.getBytes(StandardCharsets.UTF_8), tex == null ? new byte[0] : tex);
        return new Entry(id, packed, model.animationNames(), tex != null);
    }

    // --------------------------------------------------------- empaquetado (red)

    public static byte[] pack(byte[] modelJson, byte[] texture) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(new GZIPOutputStream(bos))) {
            out.writeInt(1);
            out.writeInt(modelJson.length);
            out.write(modelJson);
            out.writeInt(texture.length);
            out.write(texture);
        }
        return bos.toByteArray();
    }

    public static Bundle unpack(byte[] packed) throws IOException {
        final int max = 32 * 1024 * 1024;
        try (DataInputStream in = new DataInputStream(new GZIPInputStream(new ByteArrayInputStream(packed)))) {
            int version = in.readInt();
            if (version != 1) throw new IOException("version de paquete desconocida: " + version);
            int jl = in.readInt();
            if (jl < 0 || jl > max) throw new IOException("tamano de modelo invalido");
            byte[] json = in.readNBytes(jl);
            int tl = in.readInt();
            if (tl < 0 || tl > max) throw new IOException("tamano de textura invalido");
            byte[] tex = in.readNBytes(tl);
            return new Bundle(json, tex);
        }
    }
}
