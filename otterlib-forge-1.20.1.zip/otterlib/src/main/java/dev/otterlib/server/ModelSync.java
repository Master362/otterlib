package dev.otterlib.server;

import dev.otterlib.net.OtterNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Envia biblioteca, asignaciones y animaciones a los clientes. */
public final class ModelSync {
    private static final int CHUNK = 30_000;

    private ModelSync() {}

    public static void sendLibrary(ServerPlayer player) {
        sendLibrary(PacketDistributor.PLAYER.with(() -> player));
    }

    public static void broadcastLibrary() {
        sendLibrary(PacketDistributor.ALL.noArg());
    }

    private static void sendLibrary(PacketDistributor.PacketTarget target) {
        List<ModelLibrary.Entry> list = new ArrayList<>(ModelLibrary.entries());
        List<String> ids = new ArrayList<>();
        for (ModelLibrary.Entry e : list) ids.add(e.id());
        OtterNetwork.CHANNEL.send(target, new OtterNetwork.ModelList(ids));
        for (ModelLibrary.Entry e : list) {
            byte[] data = e.packed();
            int total = Math.max(1, (data.length + CHUNK - 1) / CHUNK);
            for (int i = 0; i < total; i++) {
                byte[] part = Arrays.copyOfRange(data, i * CHUNK, Math.min(data.length, (i + 1) * CHUNK));
                OtterNetwork.CHANNEL.send(target, new OtterNetwork.ModelChunk(e.id(), i, total, part));
            }
        }
    }

    public static void sendAssignments(ServerPlayer player) {
        Map<UUID, String> all = new HashMap<>(AssignmentData.get(player.server).all());
        OtterNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OtterNetwork.Assignments(all, true));
    }

    public static void broadcastAssignment(UUID player, String modelOrNull) {
        Map<UUID, String> one = new HashMap<>();
        one.put(player, modelOrNull == null ? "" : modelOrNull);
        OtterNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new OtterNetwork.Assignments(one, false));
    }

    public static void broadcastAnimation(UUID player, String animationOrEmpty, int mode) {
        OtterNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new OtterNetwork.PlayAnimation(player, animationOrEmpty, mode));
    }
}
