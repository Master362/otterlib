package dev.otterlib.server;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Asignaciones jugador (UUID) -> id de modelo. Se guarda en world/data/otterlib_assignments.dat. */
public class AssignmentData extends SavedData {
    private static final String NAME = "otterlib_assignments";
    private final Map<UUID, String> map = new HashMap<>();

    public static AssignmentData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(AssignmentData::load, AssignmentData::new, NAME);
    }

    public static AssignmentData load(CompoundTag tag) {
        AssignmentData data = new AssignmentData();
        ListTag list = tag.getList("assignments", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag e = list.getCompound(i);
            if (e.hasUUID("uuid") && e.contains("model", Tag.TAG_STRING)) {
                data.map.put(e.getUUID("uuid"), e.getString("model"));
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, String> en : map.entrySet()) {
            CompoundTag e = new CompoundTag();
            e.putUUID("uuid", en.getKey());
            e.putString("model", en.getValue());
            list.add(e);
        }
        tag.put("assignments", list);
        return tag;
    }

    public String get(UUID id) {
        return map.get(id);
    }

    public void set(UUID id, String model) {
        map.put(id, model);
        setDirty();
    }

    public boolean remove(UUID id) {
        boolean had = map.remove(id) != null;
        if (had) setDirty();
        return had;
    }

    public Map<UUID, String> all() {
        return Collections.unmodifiableMap(map);
    }
}
