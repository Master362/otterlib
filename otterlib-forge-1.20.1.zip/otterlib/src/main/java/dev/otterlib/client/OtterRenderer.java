package dev.otterlib.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.otterlib.model.BbModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.UUID;

/** Dibuja un BbModel en lugar del modelo vanilla del jugador. */
public final class OtterRenderer {
    private static final float D2R = (float) (Math.PI / 180.0);
    private static final float[] ROT = new float[3];
    private static final float[] POS = new float[3];
    private static final float[] SCL = new float[3];

    private OtterRenderer() {}

    private static final class Ctx {
        PoseStack ps;
        VertexConsumer vc;
        int overlay;
        int light;
        BbModel.Animation anim;
        float time;
        float headYaw;
        float pitch;
    }

    public static void render(Player player, LoadedModel lm, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        BbModel model = lm.model;
        Ctx c = new Ctx();
        c.ps = ps;
        c.light = light;
        c.overlay = LivingEntityRenderer.getOverlayCoords(player, 0.0F);

        float bodyYaw = Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot);
        float headYawAbs = Mth.rotLerp(partialTick, player.yHeadRotO, player.yHeadRot);
        c.headYaw = Mth.clamp(Mth.wrapDegrees(headYawAbs - bodyYaw), -80.0F, 80.0F);
        c.pitch = Mth.lerp(partialTick, player.xRotO, player.getXRot());

        selectAnimation(player, model, partialTick, c);

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - bodyYaw));
        ps.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        c.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(lm.texture()));
        renderNode(model.root, c);
        ps.popPose();
    }

    private static void selectAnimation(Player player, BbModel model, float pt, Ctx c) {
        UUID id = player.getUUID();
        float now = player.level().getGameTime() + pt;

        ClientModelStore.ActiveAnim act = ClientModelStore.animationOf(id);
        if (act != null) {
            BbModel.Animation a = model.findAnimation(act.name());
            if (a == null) {
                ClientModelStore.setAnimation(id, null);
            } else {
                BbModel.LoopMode mode = switch (act.mode()) {
                    case 1 -> BbModel.LoopMode.LOOP;
                    case 2 -> BbModel.LoopMode.ONCE;
                    case 3 -> BbModel.LoopMode.HOLD;
                    default -> a.loop;
                };
                float t = (now - act.startTick()) / 20.0F;
                if (mode == BbModel.LoopMode.ONCE && t > a.length) {
                    ClientModelStore.setAnimation(id, null);
                } else {
                    c.anim = a;
                    c.time = a.wrap(t, mode);
                    return;
                }
            }
        }

        double dx = player.getX() - player.xo;
        double dz = player.getZ() - player.zo;
        boolean moving = Math.sqrt(dx * dx + dz * dz) > 0.02D;
        String[] candidates;
        if (player.isSwimming() || (player.isInWater() && moving)) {
            candidates = new String[]{"swim", "walk", "idle"};
        } else if (player.isCrouching()) {
            candidates = moving ? new String[]{"sneak_walk", "sneak", "walk", "idle"} : new String[]{"sneak", "idle"};
        } else if (moving) {
            candidates = player.isSprinting() ? new String[]{"run", "walk", "idle"} : new String[]{"walk", "idle"};
        } else {
            candidates = new String[]{"idle"};
        }
        for (String name : candidates) {
            BbModel.Animation a = model.findAnimation(name);
            if (a != null) {
                c.anim = a;
                c.time = a.wrap((player.tickCount + pt) / 20.0F, BbModel.LoopMode.LOOP);
                return;
            }
        }
    }

    private static void renderNode(BbModel.Node n, Ctx c) {
        float rx = n.rotation[0], ry = n.rotation[1], rz = n.rotation[2];
        float px = 0, py = 0, pz = 0;
        float sx = 1, sy = 1, sz = 1;
        if (c.anim != null) {
            c.anim.sample(n, c.time, ROT, POS, SCL);
            // Convenciones de Blockbench: rotacion X/Y invertida, posicion X invertida.
            rx -= ROT[0];
            ry -= ROT[1];
            rz += ROT[2];
            px = -POS[0];
            py = POS[1];
            pz = POS[2];
            sx = SCL[0];
            sy = SCL[1];
            sz = SCL[2];
        }
        if (n.isHead) {
            rx -= c.pitch;
            ry -= c.headYaw;
        }

        PoseStack ps = c.ps;
        ps.pushPose();
        ps.translate(n.origin[0] + px, n.origin[1] + py, n.origin[2] + pz);
        if (rx != 0 || ry != 0 || rz != 0) {
            ps.mulPose(new Quaternionf().rotationZYX(rz * D2R, ry * D2R, rx * D2R));
        }
        if (sx != 1 || sy != 1 || sz != 1) {
            ps.scale(sx, sy, sz);
        }
        ps.translate(-n.origin[0], -n.origin[1], -n.origin[2]);

        if (!n.quads.isEmpty()) {
            PoseStack.Pose last = ps.last();
            Matrix4f pose = last.pose();
            Matrix3f normal = last.normal();
            for (BbModel.Quad q : n.quads) {
                for (int i = 0; i < 4; i++) {
                    c.vc.vertex(pose, q.x[i], q.y[i], q.z[i])
                            .color(255, 255, 255, 255)
                            .uv(q.u[i], q.v[i])
                            .overlayCoords(c.overlay)
                            .uv2(c.light)
                            .normal(normal, q.nx, q.ny, q.nz)
                            .endVertex();
                }
            }
        }
        for (BbModel.Node child : n.children) renderNode(child, c);
        ps.popPose();
    }

    /** Etiqueta con el nombre sobre la cabeza (el render vanilla se cancela, asi que se dibuja aqui). */
    public static void renderNameTag(Player player, PoseStack ps, MultiBufferSource buffers, int light) {
        Minecraft mc = Minecraft.getInstance();
        if (!Minecraft.renderNames() || player == mc.getCameraEntity()) return;
        EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
        if (dispatcher.distanceToSqr(player) > 4096.0D) return;

        boolean seeThrough = !player.isDiscrete();
        Component name = player.getDisplayName();
        Font font = mc.font;

        ps.pushPose();
        ps.translate(0.0D, player.getBbHeight() + 0.5F, 0.0D);
        ps.mulPose(dispatcher.cameraOrientation());
        ps.scale(-0.025F, -0.025F, 0.025F);
        Matrix4f m = ps.last().pose();
        int background = (int) (mc.options.getBackgroundOpacity(0.25F) * 255.0F) << 24;
        float x = -font.width(name) / 2.0F;
        font.drawInBatch(name, x, 0.0F, 0x20FFFFFF, false, m, buffers,
                seeThrough ? Font.DisplayMode.SEE_THROUGH : Font.DisplayMode.NORMAL, background, light);
        if (seeThrough) {
            font.drawInBatch(name, x, 0.0F, -1, false, m, buffers, Font.DisplayMode.NORMAL, 0, light);
        }
        ps.popPose();
    }
}
