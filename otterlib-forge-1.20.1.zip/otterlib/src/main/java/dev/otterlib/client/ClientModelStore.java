package dev.otterlib.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Estado del lado cliente (solo se toca desde el hilo principal). */
public final class ClientModelStore {
    public record ActiveAnim(String name, int mode, long startTick) {}

    private static final Map<String, LoadedModel> MODELS = new HashMap<>();
    private static final Map<UUID, String> ASSIGNMENTS = new HashMap<>();
    private static final Map<UUID, ActiveAnim> ANIMATIONS = new HashMap<>();

    private ClientModelStore() {}

    public static void putModel(LoadedModel m) {
        LoadedModel old = MODELS.put(m.id, m);
        if (old != null) old.dispose();
    }

    public static void retainOnly(Set<String> ids) {
        MODELS.entrySet().removeIf(e -> {
            if (ids.contains(e.getKey())) return false;
            e.getValue().dispose();
            return true;
        });
    }

    public static LoadedModel model(String id) {
        return MODELS.get(id);
    }

    public static String assignmentOf(UUID player) {
        return ASSIGNMENTS.get(player);
    }

    public static void setAssignment(UUID player, String model) {
        if (model == null || model.isEmpty()) {
            ASSIGNMENTS.remove(player);
            ANIMATIONS.remove(player);
        } else {
            ASSIGNMENTS.put(player, model);
        }
    }

    public static void replaceAssignments(Map<UUID, String> all) {
        ASSIGNMENTS.clear();
        ASSIGNMENTS.putAll(all);
    }

    public static ActiveAnim animationOf(UUID player) {
        return ANIMATIONS.get(player);
    }

    public static void setAnimation(UUID player, ActiveAnim anim) {
        if (anim == null) ANIMATIONS.remove(player);
        else ANIMATIONS.put(player, anim);
    }

    public static void clearAll() {
        for (LoadedModel m : MODELS.values()) m.dispose();
        MODELS.clear();
        ASSIGNMENTS.clear();
        ANIMATIONS.clear();
    }
}
