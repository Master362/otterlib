package dev.otterlib.client;

import com.mojang.blaze3d.platform.NativeImage;
import dev.otterlib.OtterLib;
import dev.otterlib.model.BbModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;

import java.io.ByteArrayInputStream;
import java.io.IOException;

/** Modelo recibido del servidor + su textura dinamica (se crea de forma perezosa en el hilo de render). */
public final class LoadedModel {
    private static int counter = 0;

    public final String id;
    public final BbModel model;
    private final byte[] textureBytes;
    private ResourceLocation texture;
    private boolean ownsTexture;

    public LoadedModel(String id, BbModel model, byte[] textureBytes) {
        this.id = id;
        this.model = model;
        this.textureBytes = textureBytes;
    }

    public ResourceLocation texture() {
        if (texture == null) {
            texture = MissingTextureAtlasSprite.getLocation();
            if (textureBytes != null && textureBytes.length > 0) {
                try (ByteArrayInputStream in = new ByteArrayInputStream(textureBytes)) {
                    NativeImage image = NativeImage.read(in);
                    DynamicTexture dyn = new DynamicTexture(image);
                    ResourceLocation rl = new ResourceLocation(OtterLib.MODID, "dynamic/" + id + "_" + (counter++));
                    Minecraft.getInstance().getTextureManager().register(rl, dyn);
                    texture = rl;
                    ownsTexture = true;
                } catch (IOException | RuntimeException ex) {
                    OtterLib.LOGGER.warn("[OtterLib] Textura invalida en el modelo '{}': {}", id, ex.getMessage());
                }
            }
        }
        return texture;
    }

    public void dispose() {
        if (ownsTexture && texture != null) {
            Minecraft.getInstance().getTextureManager().release(texture);
        }
        texture = null;
        ownsTexture = false;
    }
}
