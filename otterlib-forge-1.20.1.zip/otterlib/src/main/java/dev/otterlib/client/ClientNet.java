package dev.otterlib.client;

import dev.otterlib.OtterLib;
import dev.otterlib.model.BbModel;
import dev.otterlib.net.OtterNetwork;
import dev.otterlib.server.ModelLibrary;
import net.minecraft.client.Minecraft;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/** Manejadores de paquetes del lado cliente (se ejecutan en el hilo principal). */
public final class ClientNet {
    private static final class Assembly {
        final byte[][] parts;
        int received;

        Assembly(int total) {
            parts = new byte[total][];
        }
    }

    private static final Map<String, Assembly> PENDING = new HashMap<>();

    private ClientNet() {}

    public static void onModelList(OtterNetwork.ModelList msg) {
        ClientModelStore.retainOnly(new HashSet<>(msg.ids()));
        PENDING.clear();
    }

    public static void onModelChunk(OtterNetwork.ModelChunk msg) {
        if (msg.total() < 1 || msg.total() > 4096 || msg.index() < 0 || msg.index() >= msg.total()) return;
        Assembly a = PENDING.get(msg.id());
        if (a == null || a.parts.length != msg.total()) {
            a = new Assembly(msg.total());
            PENDING.put(msg.id(), a);
        }
        if (a.parts[msg.index()] == null) {
            a.parts[msg.index()] = msg.data();
            a.received++;
        }
        if (a.received < a.parts.length) return;

        PENDING.remove(msg.id());
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            for (byte[] p : a.parts) bos.write(p);
            ModelLibrary.Bundle bundle = ModelLibrary.unpack(bos.toByteArray());
            BbModel model = BbModel.parse(new String(bundle.modelJson(), StandardCharsets.UTF_8));
            ClientModelStore.putModel(new LoadedModel(msg.id(), model, bundle.texture()));
        } catch (Exception ex) {
            OtterLib.LOGGER.error("[OtterLib] No se pudo cargar el modelo '{}' recibido del servidor", msg.id(), ex);
        }
    }

    public static void onAssignments(OtterNetwork.Assignments msg) {
        if (msg.full()) {
            ClientModelStore.replaceAssignments(msg.map());
        } else {
            msg.map().forEach(ClientModelStore::setAssignment);
        }
    }

    public static void onPlayAnimation(OtterNetwork.PlayAnimation msg) {
        if (msg.animation().isEmpty()) {
            ClientModelStore.setAnimation(msg.player(), null);
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        ClientModelStore.setAnimation(msg.player(),
                new ClientModelStore.ActiveAnim(msg.animation(), msg.mode(), mc.level.getGameTime()));
    }
}
