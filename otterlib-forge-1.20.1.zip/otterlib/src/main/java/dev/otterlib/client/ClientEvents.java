package dev.otterlib.client;

import dev.otterlib.OtterLib;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = OtterLib.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        Player player = event.getEntity();
        String modelId = ClientModelStore.assignmentOf(player.getUUID());
        if (modelId == null) return;
        LoadedModel lm = ClientModelStore.model(modelId);
        if (lm == null) return; // modelo aun no recibido o inexistente: render vanilla

        event.setCanceled(true);
        if (player.isInvisible()) return;
        OtterRenderer.render(player, lm, event.getPartialTick(), event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight());
        OtterRenderer.renderNameTag(player, event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight());
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientModelStore.clearAll();
    }
}
