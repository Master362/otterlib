package dev.otterlib;

import com.mojang.logging.LogUtils;
import dev.otterlib.net.OtterNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(OtterLib.MODID)
public class OtterLib {
    public static final String MODID = "otterlib";
    public static final Logger LOGGER = LogUtils.getLogger();

    public OtterLib() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(OtterNetwork::register);
    }
}
