#!/usr/bin/env bash
set -e
java -version
chmod +x gradlew
./gradlew --version
echo "Listo. Compila con: ./gradlew build   (JAR en build/libs/)"
