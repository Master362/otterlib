# libs/

Carpeta reservada para JAR locales usados **solo al compilar** (`compileOnly fileTree(dir: 'libs', include: ['*.jar'])` en `build.gradle`).

- Úsala para librerías Java planas. **No** coloques aquí mods de Minecraft ofuscados: para eso hace falta `fg.deobf(...)` con un repositorio Maven o un `flatDir`.
- OtterLib actualmente **no necesita ningún JAR externo**: usa solo Forge 47.x, Minecraft 1.20.1, Gson y JOML (incluidos en el juego).
- Los `.jar` de esta carpeta no se suben a Git (ver `.gitignore`).
