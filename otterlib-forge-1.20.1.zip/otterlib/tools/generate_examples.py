#!/usr/bin/env python3
"""Genera los modelos de ejemplo (.bbmodel + PNG) de src/main/resources/otterlib_examples/.
Solo usa la libreria estandar. Los .bbmodel resultantes se pueden abrir y editar en Blockbench
(Formato "Generic Model" / free, con Box UV)."""
import base64, json, os, struct, uuid, zlib

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "otterlib_examples")


def uid(key):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "otterlib/" + key))


class Canvas:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.px = [[(0, 0, 0, 0) for _ in range(w)] for _ in range(h)]

    def rect(self, x, y, w, h, c):
        for yy in range(int(y), int(y + h)):
            for xx in range(int(x), int(x + w)):
                if 0 <= xx < self.w and 0 <= yy < self.h:
                    self.px[yy][xx] = c

    def png(self):
        raw = b"".join(b"\x00" + b"".join(bytes(p) for p in row) for row in self.px)

        def chunk(t, d):
            return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

        return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 6, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (255,)


def box_rects(uv, size):
    u, v = uv
    w, h, d = [int(round(s)) for s in size]
    return {
        "north": (u + d, v + d, w, h), "east": (u, v + d, d, h), "south": (u + 2 * d + w, v + d, w, h),
        "west": (u + d + w, v + d, d, h), "up": (u + d, v, w, d), "down": (u + d + w, v, w, d),
    }


class Model:
    def __init__(self, name, tw, th):
        self.name, self.tw, self.th = name, tw, th
        self.elements, self.outliner, self.groups, self.cubes, self.animations = [], [], {}, [], []

    def group(self, name, origin, parent=None):
        g = {"name": name, "origin": list(origin), "color": 0, "uuid": uid(self.name + "/g/" + name),
             "export": True, "isOpen": True, "visibility": True, "children": []}
        (self.outliner if parent is None else self.groups[parent]["children"]).append(g)
        self.groups[name] = g

    def cube(self, group, name, frm, to, uv, color):
        size = [to[i] - frm[i] for i in range(3)]
        rects = box_rects(uv, size)
        faces = {k: {"uv": [r[0], r[1], r[0] + r[2], r[1] + r[3]], "texture": 0} for k, r in rects.items()}
        eid = uid(self.name + "/e/" + name)
        self.elements.append({
            "name": name, "type": "cube", "uuid": eid, "from": frm, "to": to, "origin": [0, 0, 0],
            "rotation": [0, 0, 0], "box_uv": True, "uv_offset": list(uv), "autouv": 0, "color": 0,
            "export": True, "locked": False, "inflate": 0, "faces": faces})
        self.groups[group]["children"].append(eid)
        self.cubes.append((uv, size, color))

    def anim(self, name, length, loop, tracks):
        animators = {}
        for bone, chans in tracks.items():
            kfs = []
            for ch, pts in chans.items():
                for i, (t, v) in enumerate(pts):
                    kfs.append({"channel": ch, "data_points": [{"x": v[0], "y": v[1], "z": v[2]}],
                                "uuid": uid("%s/a/%s/%s/%s/%d" % (self.name, name, bone, ch, i)),
                                "time": t, "color": -1, "interpolation": "linear"})
            animators[self.groups[bone]["uuid"]] = {"name": bone, "type": "bone", "keyframes": kfs}
        self.animations.append({"uuid": uid(self.name + "/anim/" + name), "name": name, "loop": loop,
                                "override": False, "length": length, "snapping": 24, "selected": False,
                                "animators": animators})

    def paint(self, painter=None):
        cv = Canvas(self.tw, self.th)
        for uv, size, color in self.cubes:
            for face, (x, y, w, h) in box_rects(uv, size).items():
                f = 1.15 if face == "up" else 0.7 if face == "down" else 0.9 if face in ("east", "west") else 1.0
                cv.rect(x, y, w, h, shade(color, f))
        if painter:
            painter(cv)
        return cv

    def to_json(self, canvas, embed=True):
        tex = {"path": "", "name": "texture.png", "folder": "", "namespace": "", "id": "0",
               "width": self.tw, "height": self.th, "uv_width": self.tw, "uv_height": self.th,
               "particle": False, "visible": True, "mode": "bitmap", "saved": False,
               "uuid": uid(self.name + "/tex")}
        if embed:
            tex["source"] = "data:image/png;base64," + base64.b64encode(canvas.png()).decode()
        return json.dumps({
            "meta": {"format_version": "4.10", "model_format": "free", "box_uv": True},
            "name": self.name, "model_identifier": "", "visible_box": [1, 1, 0],
            "resolution": {"width": self.tw, "height": self.th},
            "elements": self.elements, "outliner": self.outliner, "textures": [tex],
            "animations": self.animations}, indent=1)


def swing(a, period, phase=1):
    h = period / 2
    return [(0, (a * phase, 0, 0)), (h, (-a * phase, 0, 0)), (period, (a * phase, 0, 0))]


def build_otter():
    m = Model("otter", 64, 64)
    brown, cream, dark = (122, 82, 48, 255), (226, 200, 154, 255), (56, 38, 26, 255)
    m.group("body", [0, 9, 0])
    m.cube("body", "torso", [-4, 9, -2], [4, 19, 2], (16, 16), brown)
    m.group("head", [0, 19, 0])
    m.cube("head", "skull", [-4, 19, -4], [4, 27, 4], (0, 0), brown)
    m.cube("head", "snout", [-2, 20, -6], [2, 23, -4], (32, 0), cream)
    m.cube("head", "ear_r", [2.5, 27, -1], [4.5, 29, 1], (32, 8), dark)
    m.cube("head", "ear_l", [-4.5, 27, -1], [-2.5, 29, 1], (40, 8), dark)
    m.group("right_arm", [5, 18, 0])   # +X = lado derecho del personaje
    m.cube("right_arm", "arm_r", [4, 10, -1.5], [7, 18, 1.5], (40, 16), brown)
    m.group("left_arm", [-5, 18, 0])
    m.cube("left_arm", "arm_l", [-7, 10, -1.5], [-4, 18, 1.5], (40, 28), brown)
    m.group("right_leg", [2, 9, 0])
    m.cube("right_leg", "leg_r", [0, 0, -2], [4, 9, 2], (0, 16), dark)
    m.group("left_leg", [-2, 9, 0])
    m.cube("left_leg", "leg_l", [-4, 0, -2], [0, 9, 2], (0, 32), dark)
    m.group("tail", [0, 11, 2])
    m.cube("tail", "tail_base", [-1.5, 9, 2], [1.5, 12, 10], (24, 32), brown)
    m.group("tail_tip", [0, 10.5, 10], parent="tail")
    m.cube("tail_tip", "tail_end", [-1, 9.5, 10], [1, 11.5, 14], (48, 40), dark)

    def sway(a, p):
        h = p / 4
        return [(0, (0, 0, 0)), (h, (0, a, 0)), (2 * h, (0, 0, 0)), (3 * h, (0, -a, 0)), (p, (0, 0, 0))]

    m.anim("idle", 2.0, "loop", {
        "tail": {"rotation": sway(8, 2.0)},
        "body": {"position": [(0, (0, 0, 0)), (1.0, (0, 0.5, 0)), (2.0, (0, 0, 0))]},
        "head": {"rotation": [(0, (0, 0, 0)), (1.0, (2, 0, 0)), (2.0, (0, 0, 0))]}})
    m.anim("walk", 1.0, "loop", {
        "right_arm": {"rotation": swing(30, 1.0)}, "left_arm": {"rotation": swing(30, 1.0, -1)},
        "right_leg": {"rotation": swing(30, 1.0, -1)}, "left_leg": {"rotation": swing(30, 1.0)},
        "tail": {"rotation": sway(12, 1.0)},
        "body": {"position": [(0, (0, 0, 0)), (0.25, (0, 0.6, 0)), (0.5, (0, 0, 0)), (0.75, (0, 0.6, 0)), (1.0, (0, 0, 0))]}})
    m.anim("run", 0.6, "loop", {
        "right_arm": {"rotation": swing(55, 0.6)}, "left_arm": {"rotation": swing(55, 0.6, -1)},
        "right_leg": {"rotation": swing(50, 0.6, -1)}, "left_leg": {"rotation": swing(50, 0.6)},
        "tail": {"rotation": sway(15, 0.6)},
        "body": {"rotation": [(0, (12, 0, 0)), (0.6, (12, 0, 0))]}})
    m.anim("sneak", 1.0, "loop", {
        "body": {"rotation": [(0, (18, 0, 0)), (1.0, (18, 0, 0))], "position": [(0, (0, -1.5, 0)), (1.0, (0, -1.5, 0))]},
        "tail": {"rotation": sway(5, 1.0)}})
    m.anim("swim", 1.2, "loop", {
        "right_arm": {"rotation": [(0, (0, 0, 40)), (0.6, (0, 0, 85)), (1.2, (0, 0, 40))]},
        "left_arm": {"rotation": [(0, (0, 0, -40)), (0.6, (0, 0, -85)), (1.2, (0, 0, -40))]},
        "right_leg": {"rotation": swing(25, 0.6)}, "left_leg": {"rotation": swing(25, 0.6, -1)},
        "tail": {"rotation": sway(20, 1.2)}})
    m.anim("wave", 1.5, "once", {
        "right_arm": {"rotation": [(0, (0, 0, 0)), (0.3, (0, 0, 150)), (0.55, (0, 0, 135)), (0.8, (0, 0, 165)),
                                    (1.05, (0, 0, 135)), (1.2, (0, 0, 150)), (1.5, (0, 0, 0))]},
        "head": {"rotation": [(0, (0, 0, 0)), (0.3, (0, 0, 8)), (1.2, (0, 0, 8)), (1.5, (0, 0, 0))]}})
    m.anim("dance", 2.0, "loop", {
        "body": {"position": [(0, (0, 0, 0)), (0.5, (0, 1.5, 0)), (1.0, (0, 0, 0)), (1.5, (0, 1.5, 0)), (2.0, (0, 0, 0))],
                 "rotation": [(0, (0, 0, 6)), (1.0, (0, 0, -6)), (2.0, (0, 0, 6))]},
        "right_arm": {"rotation": [(0, (0, 0, 140)), (1.0, (0, 0, 40)), (2.0, (0, 0, 140))]},
        "left_arm": {"rotation": [(0, (0, 0, -40)), (1.0, (0, 0, -140)), (2.0, (0, 0, -40))]},
        "tail": {"rotation": sway(25, 1.0)}})

    def painter(cv):
        # ojos en la cara frontal (north) de la cabeza: rect (8,8,8,8)
        for ex in (1, 5):
            cv.rect(8 + ex, 8 + 3, 2, 2, (255, 255, 255, 255))
        cv.rect(8 + 2, 8 + 4, 1, 1, (0, 0, 0, 255))
        cv.rect(8 + 5, 8 + 4, 1, 1, (0, 0, 0, 255))
        # nariz en el hocico (north del hocico: u=32+2, v=0+2, 4x3)
        cv.rect(32 + 2 + 1, 0 + 2, 2, 1, (20, 14, 10, 255))
        # barriga crema en el torso (north: 16+4, 16+4, 8x10)
        cv.rect(16 + 4 + 1, 16 + 4 + 1, 6, 8, cream)
    return m, painter


def build_biped():
    m = Model("biped_demo", 64, 64)
    skin, shirt, pants = (233, 189, 150, 255), (70, 120, 200, 255), (60, 60, 90, 255)
    m.group("head", [0, 24, 0])
    m.cube("head", "head", [-4, 24, -4], [4, 32, 4], (0, 0), skin)
    m.group("body", [0, 12, 0])
    m.cube("body", "body", [-4, 12, -2], [4, 24, 2], (16, 16), shirt)
    m.group("right_arm", [6, 22, 0])
    m.cube("right_arm", "arm_r", [4, 12, -2], [8, 24, 2], (40, 16), shirt)
    m.group("left_arm", [-6, 22, 0])
    m.cube("left_arm", "arm_l", [-8, 12, -2], [-4, 24, 2], (32, 48), shirt)
    m.group("right_leg", [2, 12, 0])
    m.cube("right_leg", "leg_r", [0, 0, -2], [4, 12, 2], (0, 16), pants)
    m.group("left_leg", [-2, 12, 0])
    m.cube("left_leg", "leg_l", [-4, 0, -2], [0, 12, 2], (16, 48), pants)
    m.anim("idle", 3.0, "loop", {
        "right_arm": {"rotation": [(0, (0, 0, 3)), (1.5, (0, 0, 6)), (3.0, (0, 0, 3))]},
        "left_arm": {"rotation": [(0, (0, 0, -3)), (1.5, (0, 0, -6)), (3.0, (0, 0, -3))]}})
    m.anim("walk", 1.0, "loop", {
        "right_arm": {"rotation": swing(35, 1.0)}, "left_arm": {"rotation": swing(35, 1.0, -1)},
        "right_leg": {"rotation": swing(35, 1.0, -1)}, "left_leg": {"rotation": swing(35, 1.0)}})
    m.anim("wave", 1.5, "once", {
        "right_arm": {"rotation": [(0, (0, 0, 0)), (0.3, (0, 0, 150)), (0.6, (0, 0, 130)), (0.9, (0, 0, 160)),
                                    (1.2, (0, 0, 130)), (1.5, (0, 0, 0))]}})
    m.anim("spin", 2.0, "loop", {"body": {"rotation": [(0, (0, 0, 0)), (2.0, (0, 360, 0))]}})

    def painter(cv):
        for ex in (1, 5):
            cv.rect(8 + ex, 8 + 3, 2, 2, (255, 255, 255, 255))
        cv.rect(8 + 2, 8 + 4, 1, 1, (30, 30, 80, 255))
        cv.rect(8 + 5, 8 + 4, 1, 1, (30, 30, 80, 255))
        cv.rect(8 + 3, 8 + 6, 2, 1, (150, 70, 70, 255))
    return m, painter


def write(path, data):
    full = os.path.join(OUT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "wb" if isinstance(data, bytes) else "w", **({} if isinstance(data, bytes) else {"encoding": "utf-8"})) as f:
        f.write(data)


def main():
    otter, painter = build_otter()
    brown_canvas = otter.paint(painter)
    write("otter/model.bbmodel", otter.to_json(brown_canvas))

    # Misma geometria, textura distinta: texture.png tiene prioridad sobre la incrustada.
    dark = Canvas(64, 64)
    for uv, size, color in otter.cubes:
        c = tuple(int(v * 0.45) for v in color[:3]) + (255,)
        for face, (x, y, w, h) in box_rects(uv, size).items():
            f = 1.15 if face == "up" else 0.7 if face == "down" else 0.9 if face in ("east", "west") else 1.0
            dark.rect(x, y, w, h, shade(c, f))
    painter(dark)
    write("otter_dark/model.bbmodel", otter.to_json(brown_canvas))
    write("otter_dark/texture.png", dark.png())

    biped, bpainter = build_biped()
    write("biped_demo.bbmodel", biped.to_json(biped.paint(bpainter)))
    print("Ejemplos generados en", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
